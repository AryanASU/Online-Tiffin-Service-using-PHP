<?php
// Include database connection
include('includes/dbconnection.php');

// Your Telegram bot token
$telegram_bot_token = '6666637581:AAESye96WJv3JqKusGQORM0zmzXFSAONS3I';

// Your Telegram chat ID
$telegram_chat_id = '1324347481';

if (isset($_POST['submit'])) {
    // Get form data
    $fname = $_POST['fname'];
    $mobno = $_POST['mobno'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $address = $_POST['address'];

    // Check if the email already exists
    $query = $dbh->prepare("SELECT Email FROM tbluser WHERE Email=:email");
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->execute();

    if ($query->rowCount() == 0) {
        // Insert user data into the database
        $query = $dbh->prepare("INSERT INTO tbluser (FullName, MobileNumber, Email, Password, Address) VALUES (:fname, :mobno, :email, :password, :address)");
        $query->bindParam(':fname', $fname, PDO::PARAM_STR);
        $query->bindParam(':mobno', $mobno, PDO::PARAM_INT);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->bindParam(':password', $password, PDO::PARAM_STR);
        $query->bindParam(':address', $address, PDO::PARAM_STR);
        $query->execute();

        if ($query->rowCount() > 0) {
            // User successfully registered

            // Prepare the Telegram message
            $telegram_message = "New User Registered:\n";
            $telegram_message .= "Name: $fname\n";
            $telegram_message .= "Mobile Number: $mobno\n";
            $telegram_message .= "Email: $email\n";
            $telegram_message .= "Address: $address\n";

            // Send the message to the Telegram bot
            $telegram_url = "https://api.telegram.org/bot$telegram_bot_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($telegram_message);
            file_get_contents($telegram_url);

            // Display success message
            echo '<script>alert("You have successfully registered with us."); window.location.href = "./login.php";</script>';
        } else {
            // Display error message
            echo '<script>alert("Something went wrong. Please try again.");</script>';
        }
    } else {
        // Display error message if email already exists
        echo '<script>alert("Email already exists. Please try again.");</script>';
    }
}
?>
