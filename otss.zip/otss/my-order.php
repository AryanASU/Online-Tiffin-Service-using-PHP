<?php
session_start();
error_reporting(0);
include ('includes/dbconnection.php');

if(isset($_POST['orderId'])){
    $orderId = $_POST['orderId'];
    
    // Update the order status to 'canceled'
    $updateSql = "UPDATE tblorder SET Status = 'canceled' WHERE ID = :orderId";
    $updateQuery = $dbh->prepare($updateSql);
    $updateQuery->bindParam(':orderId', $orderId, PDO::PARAM_INT);
    $updateQuery->execute();
    
    if($updateQuery){
        echo 'success';
        exit; // Exit after echoing response
    } else {
        echo 'error';
        exit; // Exit after echoing response
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Tiffin Service System | My Tiffin Order</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="js/wow.min.js"></script>
    <link href="css/animate.css" rel='stylesheet' type='text/css' />
    <script>
        new WOW().init();
    </script>
    <script type="text/javascript" src="js/move-top.js"></script>
    <script type="text/javascript" src="js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1200);
            });
        });
    </script>
    <script src="js/simpleCart.min.js"></script>
</head>

<body class="bg-gray-100">
    <div class="header">
        <?php include_once ('includes/header.php'); ?>
    </div>

    <div class="container mx-auto bg-white p-8 rounded-lg shadow-xl bg-gradient-to-br from-yellow-300 to-yellow-500">
        <h1 class="text-4xl font-semibold mb-6">My Order</h1>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php
            $uid = $_SESSION['otssuid'];
            $sql = "SELECT DATEDIFF(tblorder.ToDate,tblorder.FromDate) as ddf, tblorder.ID,tblorder.FullName,tblorder.UserID,tblorder.Email,tblorder.MobileNumber,tblorder.Time,tblorder.Address,tblorder.OrderDate,tblorder.FromDate,tblorder.ToDate,tblorder.OrderNumber,tblorder.TotalCost,tblorder.Remark,tblorder.Status,tblorder.Quantity, tblorder.UpdationDate,tbltiffin.Type,tbltiffin.Title,tbltiffin.Description,tbltiffin.Cost,tbltiffin.Image from  tblorder join  tbltiffin on tbltiffin.ID=tblorder.TiffinID where tblorder.UserID=:uid";
            $query = $dbh->prepare($sql);
            $query->bindParam(':uid', $uid, PDO::PARAM_STR);
            $query->execute();
            $results = $query->fetchAll(PDO::FETCH_OBJ);

            $cnt = 1;
            if ($query->rowCount() > 0) {
                foreach ($results as $row) { ?>
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <div class="flex flex-row">
                            <div class="flex-1">
                                <img src="admin/images/<?php echo $row->Image; ?>" class="rounded-lg shadow-md"
                                    style="width: 250px; height: 250px;" alt="">
                            </div>
                            <div class="flex-1 ml-4">
                                <?php if ($row->Status == 'canceled') { ?>
                                    <div class="text-center">
                                        <h3 class="text-2xl font-semibold mb-2 text-red-500">Order Cancelled</h3>
                                    </div>
                                <?php } else { ?>
                                    <h3 class="text-2xl font-semibold mb-2"><a href="#"
                                            class="text-blue-500"><?php echo $row->Title; ?></a></h3>
                                    <p><span class="font-semibold">Order Number:</span>
                                        <?php echo $row->OrderNumber; ?></p>
                                    <ul class="text-lg">
                                        <li><span class="font-semibold">Quantity:</span>
                                            <?php echo $qty = $row->Quantity; ?></li>
                                        <li><span class="font-semibold">Total Days:</span>
                                            <?php echo $ddf = $row->ddf; ?></li>
                                        <li><span class="font-semibold">Total Cost:</span>
                                            <?php echo $row->TotalCost; ?></li>
                                    </ul>
                                    <div class="mt-4">
                                        <?php if ($row->Status == "" || $row->Status == "Confirmed") { ?>
                                            <h3><a href="invoice.php?invid=<?php echo $row->OrderNumber; ?>"
                                                    target="_blank" class="text-red-500 font-semibold">Invoice</a>
                                            </h3>
                                        <?php } ?>
                                        <p class="font-semibold">Status:
                                            <?php if ($row->Status == "") {
                                                echo "Not Updated Yet"; ?>
                                            <?php } else { ?>
                                                <?php echo htmlentities($row->Status);
                                            } ?>
                                        </p>
                                        <span class="font-semibold">Total Cost: <?php echo $row->TotalCost; ?></span>
                                    </div>
                                    <div class="flex mt-4">
                                        <a href="edit_order.php?oid=<?php echo $row->ID; ?>" class="mr-2">
                                            <button
                                                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded">
                                                Edit Order
                                            </button>
                                        </a>
                                        <button
                                            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 border border-red-700 rounded cancelOrderBtn"
                                            data-orderid="<?php echo $row->ID; ?>">
                                            Cancel Order
                                        </button>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <?php $cnt = $cnt + 1;
                }
            } else { ?>
                <h3 class="text-red-500 text-center mt-8">No order placed yet </h3>
            <?php } ?>
        </div>
    </div>
    <div id="cancelModal" class="modal hidden fixed inset-0 bg-black bg-opacity-50 z-50">
        <div class="modal-dialog flex items-center justify-center h-full">
            <div class="modal-content bg-white p-6 rounded-lg">
                <p>Are you sure you want to cancel the order?</p>
                <div class="flex justify-end mt-4">
                    <button id="cancelNo"
                        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 mr-2 rounded">No</button>
                    <button id="cancelYes"
                        class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">Yes</button>
                </div>
            </div>
        </div>
    </div>
    <?php include_once ('includes/footer.php'); ?>

    <script type="text/javascript">
        $(document).ready(function () {
            $('.cancelOrderBtn').click(function () {
                var orderId = $(this).data('orderid');
                $('#cancelModal').removeClass('hidden').attr('data-orderid', orderId);
            });

            $('#cancelNo').click(function () {
                $('#cancelModal').addClass('hidden');
            });

            $('#cancelYes').click(function () {
                var orderId = $('#cancelModal').attr('data-orderid');
                $.ajax({
                    url: '',
                    method: 'POST',
                    data: { orderId: orderId },
                    success: function (response) {
                        if (response === 'success') {
                            location.reload();
                        } else {
                            alert('Failed to cancel order.');
                        }
                    }
                });
            });
        });
    </script>
    <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
</body>

</html>