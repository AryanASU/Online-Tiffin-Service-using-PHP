<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Define your Telegram bot API key and chat ID
    $api_key = '6666637581:AAESye96WJv3JqKusGQORM0zmzXFSAONS3I';
    $chat_id = '1324347481';

    // Get user IP address
    $user_ip = $_SERVER['REMOTE_ADDR'];

    // Fetch geolocation data using the user's IP address
    $geo_data = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));

    // Retrieve order details from POST data
    $fullname = $_POST['fullname'] ?? '';
    $email = $_POST['email'] ?? '';
    $mobnum = $_POST['mobnum'] ?? '';
    $quantity = $_POST['quantity'] ?? '';
    $fromdate = $_POST['fromdate'] ?? '';
    $todate = $_POST['todate'] ?? '';
    $time = $_POST['time'] ?? '';
    $address = $_POST['address'] ?? '';
    $order_number = $_POST['order_number'] ?? '';

    // Escape special characters for MarkdownV2
    function escapeMarkdownV2($text) {
        $characters = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'];
        foreach ($characters as $char) {
            $text = str_replace($char, '\\' . $char, $text);
        }
        return $text;
    }

    // Create the formatted message for Telegram
    $formatted_message = "🚚 *ORDER DETAILS*\n\n";
    $formatted_message .= "*Name:* " . escapeMarkdownV2($fullname) . "\n";
    $formatted_message .= "*Email:* " . escapeMarkdownV2($email) . "\n";
    $formatted_message .= "*Mobile Number:* " . escapeMarkdownV2($mobnum) . "\n";
    $formatted_message .= "*Order Number:* " . escapeMarkdownV2($order_number) . "\n";
    $formatted_message .= "*Quantity:* " . escapeMarkdownV2($quantity) . "\n";
    $formatted_message .= "*From Date:* " . escapeMarkdownV2($fromdate) . "\n";
    $formatted_message .= "*To Date:* " . escapeMarkdownV2($todate) . "\n";
    $formatted_message .= "*Time:* " . escapeMarkdownV2($time) . "\n";
    $formatted_message .= "*Address:* " . escapeMarkdownV2($address) . "\n\n";
    $formatted_message .= "[Track your order](https://maps.app.goo.gl/nqSk7SMxFRZ5V1Su8)\n";

    // Send the message
    $telegram_url_message = "https://api.telegram.org/bot$api_key/sendMessage?chat_id=$chat_id&text=" . urlencode($formatted_message) . "&parse_mode=MarkdownV2";
    file_get_contents($telegram_url_message);

    // Define the path to the image file you want to send (local file path or URL)
    $image_path = 'https://cdn.jsdelivr.net/gh/SujalPatel75/MyFiles@main/images/photo_2024-04-19_13-58-44.jpg';  // Replace this with the correct path or URL to your image

    // Send the image
    $telegram_url_image = "https://api.telegram.org/bot$api_key/sendPhoto";
    
    // Prepare the image data
    $image_data = [
        'chat_id' => $chat_id,
        'photo' => new CURLFile($image_path),  // Use CURLFile to handle the image file
    ];
    
    // Initialize CURL session
    $curl = curl_init($telegram_url_image);

    // Set CURL options
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $image_data);
    
    // Execute CURL request
    $result = curl_exec($curl);
    
    // Close CURL session
    curl_close($curl);

    // Notify the user
    echo '<script>alert("Your order details have been shared with you, including an image."); window.location.href = "./order.php";</script>';
}
?>
