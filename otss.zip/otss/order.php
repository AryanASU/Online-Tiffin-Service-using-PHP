<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

// Redirect to logout if session ID is empty
if (strlen($_SESSION['otssuid']) == 0) {
   
} else {
    if (isset($_POST['submit'])) {
        $tid = $_GET['oid'];
        $uid = $_SESSION['otssuid'];
        $fullname = $_POST['fullname'];
        $email = $_POST['email'];
        $mobnum = $_POST['mobnum'];
        $quantity = $_POST['quantity'];
        $fromdate = $_POST['fromdate'];
        $todate = $_POST['todate'];
        $time = $_POST['time'];
        $address = $_POST['address'];
        $ordernumber = mt_rand(100000000, 999999999);

        $sql = "INSERT INTO tblorder (TiffinID, UserID, OrderNumber, FullName, Email, MobileNumber, Quantity, FromDate, ToDate, Time, Address) VALUES (:tid, :uid, :ordernumber, :fullname, :email, :mobnum, :quantity, :fromdate, :todate, :time, :address)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':tid', $tid, PDO::PARAM_STR);
        $query->bindParam(':uid', $uid, PDO::PARAM_STR);
        $query->bindParam(':ordernumber', $ordernumber, PDO::PARAM_STR);
        $query->bindParam(':fullname', $fullname, PDO::PARAM_STR);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->bindParam(':mobnum', $mobnum, PDO::PARAM_STR);
        $query->bindParam(':quantity', $quantity, PDO::PARAM_STR);
        $query->bindParam(':fromdate', $fromdate, PDO::PARAM_STR);
        $query->bindParam(':todate', $todate, PDO::PARAM_STR);
        $query->bindParam(':time', $time, PDO::PARAM_STR);
        $query->bindParam(':address', $address, PDO::PARAM_STR);
        $query->execute();

        $lastInsertId = $dbh->lastInsertId();
        if ($lastInsertId > 0) {
            echo '<script>alert("Your tiffin has been ordered successfully. Your Order number is ' . $ordernumber . '")</script>';
            echo "<script>window.location.href ='index.php'</script>";
        } else {
            echo '<script>alert("Something Went Wrong. Please try again")</script>';
        }
    }
}
?>

<!DOCTYPE html>
<html class="h-full">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Tiffin Service System | Order Page</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
</head>

<body class="flex flex-col h-full">
    <?php include_once('includes/header.php'); ?>
    <div class="contact-section-page flex-1">
        <div class="contact-head bg-gray-100 py-8">
            <div class="container mx-auto">
                <h3 class="text-3xl font-bold">Tiffin Order</h3>
                <p class="text-lg">Home/Tiffin Order</p>
            </div>
        </div>
        <div class="contact_top flex-1 bg-gray-200">
            <div class="container mx-auto">
                <div class="flex flex-col md:flex-row justify-between">
                    <div class="w-full md:w-8/12 px-4">
                        <h4 class="text-2xl font-bold mb-4">Tiffin Order Form</h4>
                        <p class="mb-8">Ordering Food Was Never So Simple !!!!!!.</p>
                        <form method="post">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <?php
                                $uid = $_SESSION['otssuid'];
                                $sql = "SELECT Email, FullName, MobileNumber, Address FROM tbluser WHERE ID=:uid";
                                $query = $dbh->prepare($sql);
                                $query->bindParam(':uid', $uid, PDO::PARAM_STR);
                                $query->execute();
                                $results = $query->fetchAll(PDO::FETCH_OBJ);
                                foreach ($results as $result) {
                                ?>
                                    <input type="text" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500" placeholder="Name" readonly="true" name="fullname" value="<?php echo htmlentities($result->FullName) ?>">
                                    <input type="text" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500" placeholder="Email Address" readonly="true" name="email" value="<?php echo htmlentities($result->Email) ?>">
                                    <input type="text" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500" placeholder="Mobile Number" maxlength="10" pattern="[0-9]+" readonly="true" name="mobnum" value="<?php echo htmlentities($result->MobileNumber) ?>">
                                <?php } ?>
                                <input type="text" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500" placeholder="Quantity(eg:1,2 etc)" required="true" name="quantity">
                                <input type="date" required="true" name="fromdate" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500">
                                <input type="date" required="true" name="todate" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500">
                                <input type="time" required="true" name="time" placeholder="Tiffin Required Time" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500">
                                <textarea name="address" rows="2" placeholder="Address" required="true" readOnly="true" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500"><?php echo htmlentities($result->Address); ?></textarea>
                            </div>
                            <button type="button" onclick="enableAddressField()" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 focus:outline-none focus:bg-blue-600">Change Address</button>
                            <div class="mt-4">
                                <input name="submit" type="submit" value="Order Now" class="px-8 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 focus:outline-none focus:bg-indigo-700">
                            </div>
                        </form>
                    </div>
                    <div class="w-full md:w-4/12 px-4">
                        <?php
                        $oid = $_GET['oid'];
                        $sql = "SELECT * FROM tbltiffin WHERE ID=$oid";
                        $query = $dbh->prepare($sql);
                        $query->execute();
                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                        if ($query->rowCount() > 0) {
                            foreach ($results as $row) {
                        ?>
                                <div>
                                    <img src="admin/images/<?php echo $row->Image; ?>" width="400" height="400" />
                                </div>
                                <div class="company-right">
                                    <div class="company_ad">
                                        <h4 class="text-xl font-bold">Title</h4>
                                        <span><?php echo htmlentities($row->Title); ?></span>
                                        <p><strong>Cost :</strong> <?php echo htmlentities($row->Cost); ?></p>
                                    </div>
                                </div>
                                <div class="follow-us">
                                    <h4 class="text-xl font-bold">Description</h4>
                                    <?php echo htmlentities($row->Description); ?>
                                </div>
                        <?php }
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once('includes/footer.php'); ?>
    <script type="text/javascript">
        function enableAddressField() {
            var addressField = document.getElementsByName('address')[0];
            addressField.readOnly = false;
            addressField.value = ''; 
        }
    </script>
</body>

</html>