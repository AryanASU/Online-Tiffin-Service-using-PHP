<?php
session_start();
error_reporting(0);
include ('includes/dbconnection.php');
if (isset($_POST['submit'])) {
	$fname = $_POST['fname'];
	$mobno = $_POST['mobno'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$address = $_POST['address']; // Add this line to get the address field
	$ret = "select Email from tbluser where Email=:email";
	$query = $dbh->prepare($ret);
	$query->bindParam(':email', $email, PDO::PARAM_STR);
	$query->execute();
	$results = $query->fetchAll(PDO::FETCH_OBJ);
	if ($query->rowCount() == 0) {
		$sql = "Insert Into tbluser(FullName,MobileNumber,Email,Password,Address)Values(:fname,:mobno,:email,:password,:address)"; // Add :address parameter
		$query = $dbh->prepare($sql);
		$query->bindParam(':fname', $fname, PDO::PARAM_STR);
		$query->bindParam(':email', $email, PDO::PARAM_STR);
		$query->bindParam(':mobno', $mobno, PDO::PARAM_INT);
		$query->bindParam(':password', $password, PDO::PARAM_STR);
		$query->bindParam(':address', $address, PDO::PARAM_STR);
		$query->execute();
		$lastInsertId = $dbh->lastInsertId();
		if ($lastInsertId) {
			echo "<script>alert('You have successfully registered with us');</script>";
		} else {
			echo "<script>alert('Something went wrong. Please try again');</script>";
		}
	} else {
		echo "<script>alert('Email-id already exists. Please try again');</script>";
	}
}
?>

<script src="https://cdn.tailwindcss.com"></script>
<!DOCTYPE html>
<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php include_once ('./includes/header.php'); ?>
	<!-- source: https://gist.github.com/nraloux/bce10c4148380061781b928cdab9b193 -->
	<!-- I have added support for dark mode and improved UI -->

	<div class="h-full bg-white-500 ">
		<!-- Container -->
		<div class="mx-auto">
			<div class="flex justify-center px-6 py-12">
				<!-- Row -->
				<div class="w-full xl:w-3/4 lg:w-11/12 flex">
					<!-- Col -->
					<div class="w-full h-auto bg-gray-400 dark:bg-gray-800 hidden lg:block lg:w-5/12 bg-cover rounded-l-lg"
						style="background-image: url('./images/logintiffin.jpg'); border-radius: 5px;"></div>
					<!-- Col -->
					<div class="w-full lg:w-7/12 bg-white  p-5 rounded-lg lg:rounded-l-none">
						<h3 class="py-4 text-2xl text-center  ">Create an Account!</h3>
						<form class="px-8 pt-6 pb-8 mb-4 bg-white  rounded" method="POST" action="./mail_register.php">
							<div class="mb-4">
								<label class="block mb-2 text-sm font-bold  -700   " for="mobno">
									Full Name
								</label>
								<input
									class="w-full px-3 py-2 mb-3 text-sm leading-tight  -700    border rounded shadow appearance-none focus:outline-none focus:shadow-outline"
									name="fname" type="text" placeholder="Full name" />
							</div>
							<div class="mb-4">
								<label class="block mb-2 text-sm font-bold  -700   " for="mobno">
									Mobile Number
								</label>
								<input
									class="w-full px-3 py-2 mb-3 text-sm leading-tight  -700    border rounded shadow appearance-none focus:outline-none focus:shadow-outline"
									name="mobno" type="number" placeholder="Mobile Number" />
							</div>
							<div class="mb-4">
								<label class="block mb-2 text-sm font-bold  -700   " for="email">
									Email
								</label>
								<input
									class="w-full px-3 py-2 mb-3 text-sm leading-tight  -700    border rounded shadow appearance-none focus:outline-none focus:shadow-outline"
									name="email" type="email" placeholder="Email" />
							</div>
							<div class="mb-4">
								<label class="block mb-2 text-sm font-bold  -700   " for="email">
									Address
								</label>
								<textarea
									class="w-full px-3 py-2 mb-3 text-sm leading-tight  -700    border rounded shadow appearance-none focus:outline-none focus:shadow-outline"
									name="address" type="text" placeholder="Address" /></textarea>
							</div>
							<div class="mb-4 md:flex md:justify-between">
								<div class="mb-4 md:mr-2 md:mb-0">
									<label class="block mb-2 text-sm font-bold  -700   " for="password">
										Password
									</label>
									<input
										class="w-96 px-3 py-2 mb-3 text-sm leading-tight      border border-red-500 rounded shadow appearance-none focus:outline-none focus:shadow-outline"
										name="password" type="password" placeholder="" />
									<p class="text-xs italic text-red-500">Please choose a password.</p>
								</div>

							</div>
							<div class="mb-6 text-center">
								<input type="submit"
									class="w-full px-4 py-2 font-bold text-white bg-blue-500 rounded-full hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-900 focus:outline-none focus:shadow-outline"
									name="submit" value="Register Account">
							</div>
							<hr class="mb-6 border-t" />
							<div class="text-center">
								<a class="inline-block text-sm text-blue-500 dark:text-blue-500 align-baseline hover:text-blue-800"
									href="#">
									Forgot Password?
								</a>
							</div>
							<div class="text-center">
								<a class="inline-block text-sm text-blue-500 dark:text-blue-500 align-baseline hover:text-blue-800"
									href="./index.html">
									Already have an account? Login!
								</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<br>
	
	<!-- footer-section-ends -->
	<script type="text/javascript">
		$(document).ready(function () {
			/*
			var defaults = {
					containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

		});
	</script>
	
	<script>
		function userAvailability() {
			$("#loaderIcon").show();
			jQuery.ajax({
				url: "check_emailavailability.php",
				data: 'email=' + $("#email").val(),
				type: "POST",
				success: function (data) {
					$("#user-availability-status1").html(data);
					$("#loaderIcon").hide();
				},
				error: function () { }
			});
		}
	</script>
	<br>
	<br>
	<br>
	<br>
	<br>
	

	<?php include_once ('includes/footer.php'); ?>
	</body>

</html>