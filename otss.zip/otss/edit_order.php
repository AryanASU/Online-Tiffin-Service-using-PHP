<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (isset($_POST['submit'])) {
    // Retrieve form data
    $oid = $_GET['oid'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $mobnum = $_POST['mobnum'];
    $quantity = $_POST['quantity'];
    $fromdate = $_POST['fromdate'];
    $todate = $_POST['todate'];
    $time = $_POST['time'];
    $address = $_POST['address'];

    // Update the order details in the database
    $sql = "UPDATE tblorder SET FullName = :fullname, Email = :email, MobileNumber = :mobnum, Quantity = :quantity, FromDate = :fromdate, ToDate = :todate, Time = :time, Address = :address WHERE ID = :oid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':fullname', $fullname, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':mobnum', $mobnum, PDO::PARAM_STR);
    $query->bindParam(':quantity', $quantity, PDO::PARAM_STR);
    $query->bindParam(':fromdate', $fromdate, PDO::PARAM_STR);
    $query->bindParam(':todate', $todate, PDO::PARAM_STR);
    $query->bindParam(':time', $time, PDO::PARAM_STR);
    $query->bindParam(':address', $address, PDO::PARAM_STR);
    $query->bindParam(':oid', $oid, PDO::PARAM_INT);
    $query->execute();

    // Check if update was successful
    if ($query) {
        echo '<script>alert("Order details updated successfully.")</script>';
        echo "<script>window.location.href ='index.php'</script>";
    } else {
        echo '<script>alert("Failed to update order details. Please try again.")</script>';
    }
}

// Fetch order details using the order ID
$oid = $_GET['oid'];
$sql = "SELECT * FROM tblorder WHERE ID = :oid";
$query = $dbh->prepare($sql);
$query->bindParam(':oid', $oid, PDO::PARAM_INT);
$query->execute();
$row = $query->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html class="h-full">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Tiffin Service System | Order Page</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
</head>

<body class="flex flex-col h-full">
    <?php include_once('includes/header.php'); ?>
    <div class="contact-section-page flex-1">
        <div class="contact-head bg-gray-100 py-8">
            <div class="container mx-auto">
                <h3 class="text-3xl font-bold">Tiffin Order</h3>
                <p class="text-lg">Home/Tiffin Order</p>
            </div>
        </div>
        <div class="contact_top flex-1 bg-gray-200">
    <div class="container mx-auto">
        <div class="flex flex-col md:flex-row justify-between">
            <div class="w-full md:w-8/12 px-4">
                <h4 class="text-2xl font-bold mb-4">Tiffin Order Form</h4>
                <p class="mb-8">Ordering Food Was Never So Simple !!!!!!.</p>
                <form method="post">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php
                        $uid = $_SESSION['otssuid'];
                        $sql = "SELECT Email, FullName, MobileNumber, Address FROM tbluser WHERE ID=:uid";
                        $query = $dbh->prepare($sql);
                        $query->bindParam(':uid', $uid, PDO::PARAM_STR);
                        $query->execute();
                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                        foreach ($results as $result) {
                        ?>
                            <input type="text" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500" placeholder="Name" name="fullname" value="<?php echo htmlentities($result->FullName) ?>">
                            <input type="text" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500" placeholder="Email Address" name="email" value="<?php echo htmlentities($result->Email) ?>">
                            <input type="text" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500" placeholder="Mobile Number" maxlength="10" pattern="[0-9]+" name="mobnum" value="<?php echo htmlentities($result->MobileNumber) ?>">
                        <?php } ?>
                        <input type="number" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500" placeholder="Quantity(eg:1,2 etc)" required="true" name="quantity" id="quantity" value="<?php echo htmlentities($row['Quantity']); ?>">

                        <input type="date" required="true" name="fromdate" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500"  value="<?php echo htmlentities($row['FromDate']); ?>">
                        <input type="date" required="true" name="todate" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500"  value="<?php echo htmlentities($row['ToDate']); ?>">
                        <input type="time" required="true" name="time" placeholder="Tiffin Required Time" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500"  value="<?php echo htmlentities($row['Time']); ?>"> 
                        <textarea name="address" rows="2" placeholder="Address" required="true" class="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:border-indigo-500"><?php echo htmlentities($row['Address']); ?></textarea>
                    </div>
                    
                    <div class="mt-4">
                        <input name="submit" type="submit" value="Update Order" class="px-8 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 focus:outline-none focus:bg-indigo-700">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    <?php include_once('includes/footer.php'); ?>
    <script type="text/javascript">
        function enableAddressField() {
            var addressField = document.getElementsByName('address')[0];
            addressField.readOnly = false;
            addressField.value = ''; 
        }

        // Function to calculate total cost
        function calculateTotalCost() {
            var quantity = document.getElementById('quantity').value;
            var costPerTiffin = <?php echo $row['Cost']; ?>;
            var fromDate = new Date('<?php echo htmlentities($row['FromDate']); ?>');
            var toDate = new Date('<?php echo htmlentities($row['ToDate']); ?>');
            var totalDays = Math.ceil((toDate.getTime() - fromDate.getTime()) / (1000 * 3600 * 24));
            var totalCost = quantity * costPerTiffin * totalDays;
            document.getElementById('totalCost').innerText = "Total Cost: $" + totalCost.toFixed(2);
        }

        // Call the function on page load
        calculateTotalCost();
    </script>
</body>

</html>