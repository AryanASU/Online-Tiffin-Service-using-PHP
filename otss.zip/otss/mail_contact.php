<?php

include('includes/dbconnection.php');


$telegram_bot_token = '6666637581:AAESye96WJv3JqKusGQORM0zmzXFSAONS3I';


$telegram_chat_id = '1324347481';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

 
    $telegram_message = "New Feedback Received:\n";
    $telegram_message .= "Name: $name\n";
    $telegram_message .= "Email: $email\n";
    $telegram_message .= "Message: $message\n";

    $telegram_url = "https://api.telegram.org/bot$telegram_bot_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($telegram_message);
    file_get_contents($telegram_url);

   
    echo "<script>alert('Your feedback has been sent successfully!');</script>";
}

?>
