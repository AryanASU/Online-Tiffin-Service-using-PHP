-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 19, 2024 at 12:18 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `otssdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Admin', 'admin', 8979555559, 'adminuser@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2022-01-15 06:34:42');

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

CREATE TABLE `tblorder` (
  `ID` int(10) NOT NULL,
  `TiffinID` int(10) DEFAULT NULL,
  `UserID` int(5) NOT NULL,
  `OrderNumber` int(10) DEFAULT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Quantity` int(10) DEFAULT NULL,
  `FromDate` varchar(200) DEFAULT NULL,
  `ToDate` varchar(200) DEFAULT NULL,
  `Time` varchar(50) DEFAULT NULL,
  `Address` mediumtext DEFAULT NULL,
  `OrderDate` timestamp NULL DEFAULT current_timestamp(),
  `TotalCost` varchar(200) NOT NULL,
  `Remark` varchar(200) NOT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`ID`, `TiffinID`, `UserID`, `OrderNumber`, `FullName`, `Email`, `MobileNumber`, `Quantity`, `FromDate`, `ToDate`, `Time`, `Address`, `OrderDate`, `TotalCost`, `Remark`, `Status`, `UpdationDate`) VALUES
(7, 2, 2, 243181661, 'Rahul YADAV', 'rahul09@test.com', 1425362514, 2, '2023-01-20', '2023-02-05', '18:20', 'A 121 Arena Hieghts Sec 20 Noida 202301', '2023-01-15 09:49:12', '2400', 'Order approved', 'Confirmed', '2023-01-15 09:51:01'),
(8, 2, 2, 692034084, 'Test Test', 'test09@test.com', 1425362515, 2, '2023-01-16', '2023-01-22', '22:00', 'Test Sample', '2023-01-15 13:47:17', '900', 'confirmed', 'Confirmed', '2023-01-15 13:56:53'),
(9, 6, 3, 775005537, 'Aryan', 'aryan@gmail.com', 9427624534, 2, '2024-09-07', '2024-12-07', '21:18', '7 safalkunj society , opp. navdeep nagar , pavanchakki road , nadiad', '2024-04-15 10:47:02', '63700', 'N/A', 'Confirmed', '2024-04-15 10:47:32'),
(11, 1, 3, 607939954, 'Aryan', 'aryan@gmail.com', 9427624534, 2, '2024-04-16', '2024-04-30', '12:33', 'yoguovv', '2024-04-16 07:00:47', '1400', 'your gay', 'Canceled', '2024-04-16 07:23:32'),
(12, 2, 3, 595907941, 'Aryan', 'aryan@gmail.com', 9427624534, 2, '2024-04-16', '2024-05-01', '13:21', 'asjfnlakjsgfa', '2024-04-16 07:50:01', '2250', 'no way', 'Canceled', '2024-04-16 09:52:52'),
(14, 1, 5, 217705820, 'aryan', 'testing@gmail.com', 9427624666, 30, '2024-04-19', '2024-04-30', '09:16', 'q123123', '2024-04-19 03:44:47', '1100', '123123123123', 'canceled', '2024-04-19 06:56:54'),
(15, 2, 5, 145261341, 'aryan', 'testing@gmail.com', 9427624534, 2, '2024-04-19', '2024-05-07', '10:07', 'q123123', '2024-04-19 04:33:32', '2700', 's', 'canceled', '2024-04-19 07:04:34'),
(16, 2, 5, 698132867, 'aryan', 'testing@gmail.com', 9427624534, 32, '2024-04-19', '2024-04-23', '11:41', 'q123123', '2024-04-19 06:06:21', '4111', 'confirmed', 'canceled', '2024-04-19 09:23:01'),
(17, 3, 5, 169980418, 'aryan', 'testing@gmail.com', 9427624534, 2, '2024-04-19', '2024-04-24', '13:47', 'q123123', '2024-04-19 08:11:18', '', '', 'canceled', '2024-04-19 09:30:06'),
(18, 2, 5, 170142720, 'aryan', 'testing@gmail.com', 9427624534, 2, '2024-04-11', '2024-04-26', '14:47', 'ooga  booga nagar', '2024-04-19 09:13:27', '', '', NULL, NULL),
(19, 9, 5, 939941906, 'aryan', 'testing@gmail.com', 9427624534, 2, '2024-04-19', '2024-05-03', '14:54', 'q123123', '2024-04-19 09:21:33', '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(120) DEFAULT NULL,
  `PageTitle` mediumtext DEFAULT NULL,
  `PageDescription` mediumtext DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`) VALUES
(1, 'aboutus', 'About Us', '<h3><font size=\"5\" color=\"#000000\">Welcome to Tiffinology, where we blend tradition with taste to bring you the authentic flavors of India right to your doorstep. With a commitment to quality ingredients, homemade recipes, and timely delivery, we strive to make every meal a delightful journey through Indian cuisine. Join us in savoring the essence of home-cooked meals, crafted with love and authenticity, one Tiffin at a time</font><br></h3>', NULL, NULL, '2024-04-19 03:50:50'),
(2, 'contactus', 'Contact Us', 'D-204, Hole Town South West,Delhi-110096,India', 'info@gmail.com', 8529631232, '2023-01-14 15:56:21');

-- --------------------------------------------------------

--
-- Table structure for table `tbltiffin`
--

CREATE TABLE `tbltiffin` (
  `ID` int(10) NOT NULL,
  `Type` varchar(120) DEFAULT NULL,
  `Title` varchar(200) NOT NULL,
  `Description` mediumtext DEFAULT NULL,
  `Cost` int(10) DEFAULT NULL,
  `Image` varchar(120) DEFAULT NULL,
  `PostDate` timestamp NULL DEFAULT current_timestamp(),
  `spc_item` char(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbltiffin`
--

INSERT INTO `tbltiffin` (`ID`, `Type`, `Title`, `Description`, `Cost`, `Image`, `PostDate`, `spc_item`) VALUES
(1, 'Veg', 'Small Veg Tiffin', 'It\'s contains\r\n1. One Sabji\r\n2. Six Poori', 50, '6da996c1f71c33a49517ccba904328ca1713451394jpeg', '2023-01-06 08:22:10', NULL),
(2, 'Veg', 'Medium Veg Tiffin', 'Its Contains\r\n1. Four Roti\r\n2. One Dal\r\n3. Two Sabji\r\n4. Pickle', 75, '7fdc1a630c238af0815181f9faa190f51580901298.jpg', '2023-01-06 08:22:10', NULL),
(3, 'Veg', 'Large Veg Tiffin', 'It\'s Contains\r\n1. Four Roti\r\n2. Rice\r\n3. One Sabji\r\n4.Raita\r\n5. Salad\r\n6.Pickle', 120, '19c10f4e66067da4b5eb1dac874e46721580901461.jpg', '2023-01-06 08:22:10', NULL),
(4, 'Non Veg', 'Small Non Veg Tiffin', 'It\'s Contains\r\n1. Four Roti\r\n2. Two Missi Roti\r\n3. One Dal\r\n4. Two Sabji\r\n5. Salad\r\n6. Pickles\r\n7. Raita\r\n8. Sweets', 200, '7fdc1a630c238af0815181f9faa190f51580901580.jpg', '2023-01-06 08:22:10', NULL),
(5, 'Non Veg', 'Medium Non Veg Tiffin', 'It\'s Contains\r\n1. Four Roti\r\n2. Rice\r\n3. One Sabji\r\n4.Raita\r\n5. Salad\r\n6.Pickle', 250, 'efc1a80c391be252d7d777a437f868701580470642.jpg', '2023-01-06 08:22:10', NULL),
(6, 'Non Veg', 'Large Non Veg Tiffin', 'It\'s Contains\r\n1. Four Roti\r\n2. Rice\r\n3. One Sabji\r\n4.Raita\r\n5. Salad\r\n6.Pickle\r\n', 350, '74375080377499ab76dad37484ee7f151580881251.jpg', '2023-01-06 08:22:10', NULL),
(9, 'Veg', 'test', 'testtesttest', 123, 'b1d297fbb8ad51ec28fbaba16186fc3b1713450992jpeg', '2024-04-18 14:36:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `ID` int(10) NOT NULL,
  `FullName` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `Address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`ID`, `FullName`, `MobileNumber`, `Email`, `Password`, `RegDate`, `Address`) VALUES
(5, 'aryan', 9427624534, 'testing@gmail.com', '4297f44b13955235245b2497399d7a93', '2024-04-18 14:26:23', 'q123123'),
(6, 'Aryan', 9427624534, 'aryanpateliya321@gmail.com', '101193d7181cc88340ae5b2b17bba8a1', '2024-04-19 08:54:43', 'nad');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblorder`
--
ALTER TABLE `tblorder`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbltiffin`
--
ALTER TABLE `tbltiffin`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblorder`
--
ALTER TABLE `tblorder`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbltiffin`
--
ALTER TABLE `tbltiffin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
