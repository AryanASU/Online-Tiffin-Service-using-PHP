<?php
session_start();
error_reporting(0);
include ('includes/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    
<?php include_once ('includes/header.php'); ?>


<div class="bg-white">
     
        <div class="relative mx-auto max-w-7xl z-10 grid grid-cols-1 gap-10 pt-14 sm:grid-cols-2 lg:grid-cols-3">
            <div class="rounded-md border border-black bg-white p-8 text-center shadow">
                <div class="button-text mx-auto flex h-12 w-12 items-center justify-center rounded-md border "
                    style="background-image: linear-gradient(rgb(80, 70, 229) 0%, rgb(43, 49, 203) 100%); border-color: rgb(93, 79, 240);">
                    <i class="fa-solid fa-hand-sparkles" style="color: #FFD43B;font-size: 22px;"></i>
                </div>
                <h3 class="mt-6 text-black" style="font-style: bold;font-size: 20px;font-weight: 700;">Cleanliness</h3>
                <p class="my-4 mb-0 font-normal leading-relaxed tracking-wide text-black">
                    We keep our food making and ordering process totally clean and sustained.
                    Gloves and other equipments are used by the workers to keep it clean.
                </p>
            </div>

            <div class="rounded-md border border-black bg-white p-8 text-center shadow">
                <div class="button-text mx-auto flex h-12 w-12 items-center justify-center rounded-md border "
                    style="background-image: linear-gradient(rgb(80, 70, 229) 0%, rgb(43, 49, 203) 100%); border-color: rgb(93, 79, 240);">
                    <i class="fa-regular fa-clock" style="color: yellow;font-size: 22px;"></i>
                </div>
                <h3 class="mt-6 text-black" style="font-style: bold;font-size: 20px;font-weight: 700;">Fast Delivery</h3>
                <p class="my-4 mb-0 font-normal leading-relaxed tracking-wide text-black">
                    The food is delivered within 30 minutes.
                    The fast delivery is promised.
                </p>
            </div>

            <div class="rounded-md border border-black bg-white p-8 text-center shadow">
                <div class="button-text mx-auto flex h-12 w-12 items-center justify-center rounded-md border "
                    style="background-image: linear-gradient(rgb(80, 70, 229) 0%, rgb(43, 49, 203) 100%); border-color: rgb(93, 79, 240);">
                    <i class="fa-solid fa-heart-pulse" style="color: #FFD43B;font-size: 22px;"></i>
                </div>
                <h3 class="mt-6 text-black" style="font-style: bold;font-size: 20px;font-weight: 700;">Healthy food</h3>
                <p class="my-4 mb-0 font-normal leading-relaxed tracking-wide text-black">
                    We make our food with best quality vegetables and ingredients because customer health is our first priority.
                </p>
            </div>
        </div>
   <!-- Our description -->
        <section id="features" class="relative block px-6 py-10 md:py-20 md:px-10  border-neutral-900 ">
        <div class="relative mx-auto max-w-5xl text-center">
            <span class="text-black my-3 flex items-center justify-center font-medium uppercase tracking-wider">
                
            </span>
            <h1 class="block w-full bg-gradient-to-b from-white to-gray-400 bg-clip-text font-bold  text-3xl sm:text-4xl">
                Why choose us
            </h1>
            <p class="mx-auto my-4 w-full max-w-xl bg-transparent text-center font-medium leading-relaxed tracking-wide text-black">
            <?php
					$sql = "SELECT * from tblpage where PageType='aboutus'";
					$query = $dbh->prepare($sql);
					$query->execute();
					$results = $query->fetchAll(PDO::FETCH_OBJ);

					$cnt = 1;
					if ($query->rowCount() > 0) {
						foreach ($results as $row) { ?>

							<div>
								

								<div>
									<div class="company_ad">
										
										<br />
										<span><?php echo $row->PageDescription; ?>.</span>

									</div>
								</div>


							</div>
						</div> <?php $cnt = $cnt + 1;
						}
					} ?>
            </p>
        </div>

    
</div>
<?php include_once ('includes/footer.php'); ?>

</body>
</html>