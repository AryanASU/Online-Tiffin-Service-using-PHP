<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['otssaid']) == 0) {
    header('location:logout.php');
} else {

    if ($_GET['del']) {
        $appid = $_GET['del'];
        $sql = "delete from tbltiffin where ID='$appid'";
        $query = $dbh->prepare($sql);
        $query->execute();
        echo "<script>alert('Data Deleted');</script>";
        echo "<script>window.location.href='manage-tiffin.php'</script>";
    }
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <title>Online Tiffine Service System - Manage Tiffin</title>
    <link href="assets/extra-libs/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="dist/css/style.css" rel="stylesheet">
   
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <?php include_once('includes/header.php'); ?>
        <?php include_once('includes/sidebar.php'); ?>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Manage Tiffin</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item"><a href="dashboard.php" class="text-muted">Home</a>
                                    </li>
                                    <li class="breadcrumb-item text-muted active" aria-current="page">Manage
                                        Tiffin</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="zero_config"
                                        class="table table-striped table-bordered no-wrap">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Type</th>
                                                <th>Title</th>
                                                <th>Cost</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sql = "SELECT * from tbltiffin";
                                            $query = $dbh->prepare($sql);
                                            $query->execute();
                                            $results = $query->fetchAll(PDO::FETCH_OBJ);

                                            $cnt = 1;
                                            if ($query->rowCount() > 0) {
                                                foreach ($results as $row) {
                                            ?>
                                            <tr>
                                                <td><?php echo htmlentities($cnt); ?></td>
                                                <td><?php echo htmlentities($row->Type); ?></td>
                                                <td><?php echo htmlentities($row->Title); ?></td>
                                                <td><?php echo htmlentities($row->Cost); ?></td>
                                                <td>
                                                    <input type="text" class="form-control special-item-input" id="specialItem<?php echo htmlentities($row->ID); ?>"
                                                                        name="specialItem"
                                                                        placeholder="Enter special item name"
                                                                        required>
                                                    <button type="button" class="btn btn-primary btn-sm add-special-item" data-tiffin-id="<?php echo htmlentities($row->ID); ?>">Add Special Item</button>
                                                    <a href="edit-tiffin-detail.php?editid=<?php echo htmlentities($row->ID); ?>"
                                                        class="btn btn-primary btn-sm">Edit</a>
                                                    <a href="manage-tiffin.php?del=<?php echo htmlentities($row->ID); ?>"
                                                        onclick="return confirm('Do you really want to delete?');"
                                                        class="btn btn-danger btn-sm">Delete</a>
                                                </td>
                                            </tr>
                                            <?php
                                                    $cnt = $cnt + 1;
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="dist/js/app-style-switcher.js"></script>
    <script src="dist/js/feather.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <script src="dist/js/sidebarmenu.js"></script>
    <script src="dist/js/custom.min.js"></script>
    <script src="assets/extra-libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="dist/js/pages/datatable/datatable-basic.init.js"></script>

    <script>
        $(document).ready(function() {
            $('.add-special-item').click(function() {
                var tiffinID = $(this).data('tiffin-id');
                var specialItem = $('#specialItem' + tiffinID).val();
                // You can perform further processing with the special item value here
                // For example, send it to the server via AJAX
                console.log('Tiffin ID:', tiffinID);
                console.log('Special Item:', specialItem);
                
                // Send the special item to the server via AJAX for database storage
                $.ajax({
                    url: 'store-special-item.php', // Change the URL to your PHP script that handles database storage
                    type: 'POST',
                    data: {
                        tiffinID: tiffinID,
                        specialItem: specialItem
                    },
                    success: function(response) {
                        console.log(response); // Log the response from the server
                        alert('Special item added successfully.');
                        window.location.reload(); // Reload the page after successful addition
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText); // Log any errors to the console
                        alert('An error occurred while adding the special item.');
                    }
                });
            });
        });
    </script>
</body>

</html>
<?php
    if (isset($_POST['addSpecialItem'])) {
        $specialItem = $_POST['specialItem'];
        $tiffinID = $_POST['tiffinID']; // You need to add a hidden input field in your modal form to store the tiffin ID.

        // Update the tbltiffin table with the special item
        $sql = "UPDATE tbltiffin SET spc_item = CONCAT(spc_item, ', ', :specialItem) WHERE ID = :tiffinID";
        $query = $dbh->prepare($sql);
        $query->bindParam(':specialItem', $specialItem, PDO::PARAM_STR);
        $query->bindParam(':tiffinID', $tiffinID, PDO::PARAM_INT);
        $query->execute();
        echo "<script>alert('Special item added successfully.');</script>";
        echo "<script>window.location.href='manage-tiffin.php'</script>";
    }
?>
<?php
}
?>
