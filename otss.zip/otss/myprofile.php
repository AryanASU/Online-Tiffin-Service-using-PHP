<?php
session_start();
error_reporting(0);
include ('includes/dbconnection.php');
if (strlen($_SESSION['otssuid'] == 0)) {
  header('location:logout.php');
} else {
  if (isset($_POST['submit'])) {
    $uid = $_SESSION['otssuid'];
    $AName = $_POST['name'];
    $mobno = $_POST['mobilenumber'];
    $email = $_POST['email'];
    $sql = "update tbluser set FullName=:name,MobileNumber=:mobilenumber where ID=:uid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':name', $AName, PDO::PARAM_STR);
    $query->bindParam(':mobilenumber', $mobno, PDO::PARAM_STR);
    $query->bindParam(':uid', $uid, PDO::PARAM_STR);
    $query->execute();

    echo '<script>alert("Profile has been updated")</script>';

  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>


  <script
    type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
  <!--webfont-->
  <link
    href='//fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic'
    rel='stylesheet' type='text/css'>
  <link href='//fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet'
    type='text/css'>
  <!--Animation-->
  <script src="js/wow.min.js"></script>
  <link href="css/animate.css" rel='stylesheet' type='text/css' />

  <script src="js/jquery.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <script>
    new WOW().init();
  </script>
  <script type="text/javascript" src="js/move-top.js"></script>
  <script type="text/javascript" src="js/easing.js"></script>
  <script type="text/javascript">
    jQuery(document).ready(function ($) {
      $(".scroll").click(function (event) {
        event.preventDefault();
        $('html,body').animate({ scrollTop: $(this.hash).offset().top }, 1200);
      });
    });
  </script>
  <script src="js/simpleCart.min.js"> </script>
  <script src="https://cdn.tailwindcss.com"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/4.0.0-alpha.14/lib.min.js"
    integrity="sha512-LTxGQ9e0m5BLj8PqkTeZdQIWBCGt2L1I3dZkprWs3lwsWkiXD1j+o2rttG+40TVOQPUpQC9rykk3RPX9Dny1Bg=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>




  <!-- component -->
  <link rel="stylesheet" href="https://demos.creative-tim.com/notus-js/assets/styles/tailwind.css">
  <link rel="stylesheet"
    href="https://demos.creative-tim.com/notus-js/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css">


   <?php include_once ('includes/header.php'); ?> 



  <main class="profile-page">
    <section class="relative block h-500-px">
      
      <div class="top-auto bottom-0 left-0 right-0 w-full absolute pointer-events-none overflow-hidden h-70-px"
        style="transform: translateZ(0px)">
        <svg class="absolute bottom-0 overflow-hidden" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none"
          version="1.1" viewBox="0 0 2560 100" x="0" y="0">
          <polygon class="text-blueGray-200 fill-current" points="2560 0 2560 100 0 100"></polygon>
        </svg>
      </div>
    </section>
    <section class="relative py-16 bg-blueGray-200">
      <div class="container mx-auto px-4" >
        <div class="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-xl rounded-lg -mt-64">
          <div class="px-6">
            <div class="flex flex-wrap justify-center">
              <div class="w-full lg:w-3/12 px-4 lg:order-2 flex justify-center">
                <div class="relative" >
                  <img alt="..." src="images/user3.png" style="text-align:center;"
                    class="shadow-xl rounded-full h-auto align-middle border-none absolute -m-16 -ml-20 lg:-ml-16 max-w-150-px">
                </div>
              </div>
              <div class="w-full lg:w-4/12 px-4 lg:order-3 lg:text-right lg:self-center">
                <div class="py-6 px-3 mt-32 sm:mt-0">
                 
                </div>
              </div>
              <!-- <div class="w-full lg:w-4/12 px-4 lg:order-1">
                <div class="flex justify-center py-4 lg:pt-4 pt-8">
                  <div class="mr-4 p-3 text-center">
                    <span class="text-xl font-bold block uppercase tracking-wide text-blueGray-600">22</span><span
                      class="text-sm text-blueGray-400">Friends</span>
                  </div>
                  <div class="mr-4 p-3 text-center">
                    <span class="text-xl font-bold block uppercase tracking-wide text-blueGray-600">10</span><span
                      class="text-sm text-blueGray-400">Photos</span>
                  </div>
                  <div class="lg:mr-4 p-3 text-center">
                    <span class="text-xl font-bold block uppercase tracking-wide text-blueGray-600">89</span><span
                      class="text-sm text-blueGray-400">Comments</span>
                  </div>
                </div>
              </div> -->
            </div>
            <div class="text-center mt-12">
              <?php
              $uid = $_SESSION['otssuid'];
              $sql = "SELECT * from  tbluser where ID=:uid";
              $query = $dbh->prepare($sql);
              $query->bindParam(':uid', $uid, PDO::PARAM_STR);
              $query->execute();
              $results = $query->fetchAll(PDO::FETCH_OBJ);
              $cnt = 1;
              if ($query->rowCount() > 0) {
                foreach ($results as $row) { ?>
                  <form method="post">
                    <div class="bg-white shadow-lg rounded-lg px-8 py-6 max-w-md mx-auto">
                      <div class="mb-4">
                        <label for="name" class="block text-lg font-semibold text-gray-700 mb-2">Name</label>
                        <input type="text" id="name" name="name" value="<?php echo $row->FullName; ?>"
                          class="form-input rounded-md w-full">
                      </div>
                      <div class="mb-4">
                        <label for="email" class="block text-lg font-semibold text-gray-700 mb-2">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo $row->Email; ?>"
                          class="form-input rounded-md w-full" readonly>
                      </div>
                      <div class="mb-4">
                        <label for="mobilenumber" class="block text-lg font-semibold text-gray-700 mb-2">Contact
                          Number</label>
                        <input type="text" id="mobilenumber" name="mobilenumber" value="<?php echo $row->MobileNumber; ?>"
                          class="form-input rounded-md w-full" maxlength="10">
                      </div>
                      <div class="mb-4">
                        <label for="registrationDate" class="block text-lg font-semibold text-gray-700 mb-2">Registration
                          Date</label>
                        <input type="text" id="registrationDate" value="<?php echo $row->RegDate; ?>"
                          class="form-input rounded-md w-full" readonly>
                      </div>
                      <button type="submit" name="submit"
                        class="bg-violet-500 hover:bg-red-600 text-white  py-2 px-4 rounded-md focus:outline-none focus:shadow-outline">Update
                        Profile</button>
                    </div>
                  </form>
                <?php
                }
              } ?>
            </div>


          </div>
        </div>
      </div>

    </section>
  </main>
  <?php include_once ('includes/footer.php'); ?> 
</body>

</html>